Just a meme website. 
- Live @ https://aayushnet.tech/valentine

# Your own insta
Add your username as an id paramter at the end of the url
- Example: https://aayushnet.tech/valentine?id=@aayushh.hhhh
